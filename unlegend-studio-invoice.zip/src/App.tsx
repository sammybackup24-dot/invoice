import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  History, 
  Users, 
  ChevronRight, 
  ArrowLeft, 
  Download, 
  Share2, 
  Search,
  Clock,
  Calendar,
  Phone,
  User,
  IndianRupee,
  CheckCircle2
} from 'lucide-react';
import { format } from 'date-fns';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { cn } from './lib/utils';
import { useLocalStorage } from './hooks/useLocalStorage';
import { STUDIO_DETAILS, Invoice, Client } from './types';

// --- Components ---

const LuxuryButton = ({ 
  children, 
  onClick, 
  className, 
  variant = 'primary',
  disabled = false 
}: { 
  children: React.ReactNode; 
  onClick?: () => void; 
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  disabled?: boolean;
}) => {
  const variants = {
    primary: "bg-luxury-white text-luxury-black hover:bg-white",
    secondary: "bg-luxury-charcoal text-luxury-white hover:bg-neutral-800",
    outline: "border border-luxury-charcoal text-luxury-white hover:bg-luxury-charcoal",
    ghost: "text-luxury-silver hover:text-luxury-white hover:bg-luxury-charcoal/50"
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "px-6 py-4 rounded-2xl font-medium transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed",
        variants[variant],
        className
      )}
    >
      {children}
    </motion.button>
  );
};

const LuxuryInput = ({ 
  label, 
  value, 
  onChange, 
  type = 'text', 
  placeholder,
  icon: Icon
}: any) => (
  <div className="space-y-2">
    <label className="text-xs font-medium text-luxury-silver uppercase tracking-widest ml-1">{label}</label>
    <div className="relative group">
      {Icon && <Icon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-luxury-silver group-focus-within:text-luxury-white transition-colors" />}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={cn(
          "w-full bg-luxury-charcoal border border-transparent focus:border-luxury-silver/30 rounded-2xl py-4 transition-all outline-none text-luxury-white placeholder:text-neutral-600",
          Icon ? "pl-12 pr-4" : "px-4"
        )}
      />
    </div>
  </div>
);

const DurationSelector = ({ hours, minutes, onChange }: any) => {
  return (
    <div className="space-y-4">
      <label className="text-xs font-medium text-luxury-silver uppercase tracking-widest ml-1">Session Duration</label>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-luxury-charcoal rounded-2xl p-4 flex flex-col items-center justify-center gap-2 border border-transparent hover:border-luxury-silver/20 transition-all">
          <span className="text-3xl font-display font-bold">{hours}</span>
          <span className="text-[10px] uppercase tracking-widest text-luxury-silver">Hours</span>
          <div className="flex gap-4 mt-2">
            <button onClick={() => onChange(Math.max(0, hours - 1), minutes)} className="w-8 h-8 rounded-full bg-luxury-black flex items-center justify-center hover:bg-neutral-800">-</button>
            <button onClick={() => onChange(hours + 1, minutes)} className="w-8 h-8 rounded-full bg-luxury-black flex items-center justify-center hover:bg-neutral-800">+</button>
          </div>
        </div>
        <div className="bg-luxury-charcoal rounded-2xl p-4 flex flex-col items-center justify-center gap-2 border border-transparent hover:border-luxury-silver/20 transition-all">
          <span className="text-3xl font-display font-bold">{minutes}</span>
          <span className="text-[10px] uppercase tracking-widest text-luxury-silver">Minutes</span>
          <div className="flex gap-4 mt-2">
            <button onClick={() => onChange(hours, Math.max(0, minutes - 1))} className="w-8 h-8 rounded-full bg-luxury-black flex items-center justify-center hover:bg-neutral-800">-</button>
            <button onClick={() => onChange(hours, Math.min(59, minutes + 1))} className="w-8 h-8 rounded-full bg-luxury-black flex items-center justify-center hover:bg-neutral-800">+</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [view, setView] = useState<'home' | 'create' | 'history' | 'clients' | 'preview'>('home');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const { clients, invoices, addClient, addInvoice } = useLocalStorage();

  // Create Invoice State
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [sessionDate, setSessionDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [hours, setHours] = useState(1);
  const [minutes, setMinutes] = useState(0);
  const [hourlyRate, setHourlyRate] = useState('1000');
  const [manualTotal, setManualTotal] = useState('');

  const calculatedTotal = useMemo(() => {
    const duration = hours + minutes / 60;
    return Math.round(duration * parseFloat(hourlyRate || '0'));
  }, [hours, minutes, hourlyRate]);

  const finalTotal = manualTotal ? parseFloat(manualTotal) : calculatedTotal;

  const handleGenerateInvoice = () => {
    // Check if client exists, if not add
    let client = clients.find(c => c.phone === clientPhone);
    if (!client) {
      client = addClient({ name: clientName, phone: clientPhone });
    }

    const invoice = addInvoice({
      clientId: client.id,
      clientName: clientName,
      clientPhone: clientPhone,
      date: new Date(sessionDate).getTime(),
      durationHours: hours,
      durationMinutes: minutes,
      hourlyRate: parseFloat(hourlyRate),
      totalAmount: finalTotal,
    });

    setSelectedInvoice(invoice);
    setView('preview');
    
    // Reset form
    setClientName('');
    setClientPhone('');
    setHours(1);
    setMinutes(0);
    setManualTotal('');
  };

  const generatePDF = (invoice: Invoice) => {
    const doc = new jsPDF();
    
    // Luxury Header
    doc.setFontSize(24);
    doc.setTextColor(0, 0, 0);
    doc.text(STUDIO_DETAILS.name.toUpperCase(), 20, 30);
    
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(STUDIO_DETAILS.address, 20, 40);
    doc.text(STUDIO_DETAILS.subAddress, 20, 45);
    doc.text(STUDIO_DETAILS.city, 20, 50);
    doc.text(`Phone: ${STUDIO_DETAILS.contact}`, 20, 55);

    // Invoice Info
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.text(`INVOICE: ${invoice.invoiceNumber}`, 140, 30);
    doc.text(`DATE: ${format(invoice.date, 'dd MMM yyyy')}`, 140, 37);

    // Client Info
    doc.setDrawColor(230, 230, 230);
    doc.line(20, 65, 190, 65);
    
    doc.setFontSize(10);
    doc.text("BILL TO:", 20, 75);
    doc.setFontSize(14);
    doc.text(invoice.clientName, 20, 85);
    doc.setFontSize(10);
    doc.text(invoice.clientPhone, 20, 92);

    // Table
    autoTable(doc, {
      startY: 110,
      head: [['DESCRIPTION', 'DURATION', 'RATE', 'AMOUNT']],
      body: [
        [
          'Recording Session',
          `${invoice.durationHours}h ${invoice.durationMinutes}m`,
          `INR ${invoice.hourlyRate}/hr`,
          `INR ${invoice.totalAmount}`
        ]
      ],
      theme: 'plain',
      headStyles: { fillColor: [0, 0, 0], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 8 },
    });

    // Total
    const finalY = (doc as any).lastAutoTable.finalY + 10;
    doc.setFontSize(16);
    doc.text(`TOTAL AMOUNT: INR ${invoice.totalAmount}`, 110, finalY + 10);

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text("Thank you for choosing Unlegend Studio. All rights reserved.", 20, 280);

    try {
      doc.save(`${invoice.invoiceNumber}_${invoice.clientName}.pdf`);
    } catch (error) {
      console.error("PDF Save Error:", error);
      // Fallback for some environments
      const blob = doc.output('blob');
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${invoice.invoiceNumber}_${invoice.clientName}.pdf`;
      link.click();
    }
  };

  const shareWhatsApp = (invoice: Invoice) => {
    const message = `Hello ${invoice.clientName}, your invoice from Unlegend Studio is ready.\n\nInvoice: ${invoice.invoiceNumber}\nAmount: ₹${invoice.totalAmount}\nSession: ${invoice.durationHours}h ${invoice.durationMinutes}m\n\nThank you!`;
    const url = `https://wa.me/${invoice.clientPhone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="max-w-md mx-auto min-h-screen bg-luxury-black flex flex-col relative overflow-hidden">
      {/* Background Cinematic Glow */}
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-luxury-silver/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -right-24 w-96 h-96 bg-luxury-silver/5 rounded-full blur-3xl pointer-events-none" />

      <AnimatePresence mode="wait">
        {view === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex-1 p-8 flex flex-col"
          >
            <header className="mb-12 mt-8">
              <h1 className="text-4xl font-bold mb-2">Unlegend<br/>Studio</h1>
              <p className="text-luxury-silver text-sm tracking-widest uppercase">Invoice Manager</p>
            </header>

            <div className="grid gap-4">
              <LuxuryButton onClick={() => setView('create')} className="h-40 flex-col items-start justify-between p-6">
                <div className="w-10 h-10 rounded-full bg-luxury-black flex items-center justify-center">
                  <Plus className="w-6 h-6 text-luxury-white" />
                </div>
                <div className="text-left">
                  <span className="block text-lg font-bold">Create Invoice</span>
                  <span className="text-xs opacity-60">New recording session</span>
                </div>
              </LuxuryButton>

              <div className="grid grid-cols-2 gap-4">
                <LuxuryButton onClick={() => setView('history')} variant="secondary" className="h-32 flex-col items-start justify-between p-5">
                  <History className="w-5 h-5" />
                  <span className="font-bold">History</span>
                </LuxuryButton>
                <LuxuryButton onClick={() => setView('clients')} variant="secondary" className="h-32 flex-col items-start justify-between p-5">
                  <Users className="w-5 h-5" />
                  <span className="font-bold">Clients</span>
                </LuxuryButton>
              </div>
            </div>

            <footer className="mt-auto pt-12">
              <div className="bg-luxury-charcoal/50 rounded-3xl p-6 border border-luxury-charcoal">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs text-luxury-silver uppercase tracking-widest">Recent Activity</span>
                  <ChevronRight className="w-4 h-4 text-luxury-silver" />
                </div>
                {invoices.length > 0 ? (
                  <div className="space-y-4">
                    {invoices.slice(0, 2).map(inv => (
                      <div key={inv.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{inv.clientName}</p>
                          <p className="text-[10px] text-luxury-silver">{format(inv.date, 'dd MMM')}</p>
                        </div>
                        <p className="font-display font-bold">₹{inv.totalAmount}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-luxury-silver italic">No invoices generated yet.</p>
                )}
              </div>
            </footer>
          </motion.div>
        )}

        {view === 'create' && (
          <motion.div
            key="create"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="flex-1 p-8 flex flex-col"
          >
            <header className="flex items-center gap-4 mb-10">
              <button onClick={() => setView('home')} className="p-2 -ml-2 hover:bg-luxury-charcoal rounded-full transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h2 className="text-2xl font-bold">New Session</h2>
            </header>

            <div className="space-y-6 overflow-y-auto pb-24 no-scrollbar">
              <LuxuryInput 
                label="Client Name" 
                value={clientName} 
                onChange={setClientName} 
                placeholder="Enter client name"
                icon={User}
              />
              <LuxuryInput 
                label="Phone Number" 
                value={clientPhone} 
                onChange={setClientPhone} 
                placeholder="e.g. 9098692404"
                icon={Phone}
              />
              <LuxuryInput 
                label="Session Date" 
                type="date"
                value={sessionDate} 
                onChange={setSessionDate} 
                icon={Calendar}
              />

              <DurationSelector 
                hours={hours} 
                minutes={minutes} 
                onChange={(h: number, m: number) => { setHours(h); setMinutes(m); }} 
              />

              <div className="grid grid-cols-2 gap-4">
                <LuxuryInput 
                  label="Rate / Hour" 
                  value={hourlyRate} 
                  onChange={setHourlyRate} 
                  placeholder="1000"
                  icon={IndianRupee}
                />
                <LuxuryInput 
                  label="Manual Total" 
                  value={manualTotal} 
                  onChange={setManualTotal} 
                  placeholder={calculatedTotal.toString()}
                  icon={CheckCircle2}
                />
              </div>

              <div className="bg-luxury-charcoal/30 rounded-3xl p-8 border border-luxury-charcoal flex flex-col items-center justify-center gap-2">
                <span className="text-xs text-luxury-silver uppercase tracking-[0.2em]">Estimated Total</span>
                <motion.span 
                  key={finalTotal}
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-5xl font-display font-bold"
                >
                  ₹{finalTotal}
                </motion.span>
              </div>
            </div>

            <div className="fixed bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-luxury-black via-luxury-black to-transparent max-w-md mx-auto">
              <LuxuryButton 
                onClick={handleGenerateInvoice}
                disabled={!clientName || !clientPhone}
                className="w-full py-5 text-lg shadow-2xl shadow-white/5"
              >
                Generate Invoice
              </LuxuryButton>
            </div>
          </motion.div>
        )}

        {view === 'preview' && selectedInvoice && (
          <motion.div
            key="preview"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="flex-1 p-8 flex flex-col"
          >
            <header className="flex items-center justify-between mb-8">
              <button onClick={() => setView('home')} className="p-2 -ml-2 hover:bg-luxury-charcoal rounded-full transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h2 className="text-xl font-bold">Preview</h2>
              <div className="w-10" />
            </header>

            <div className="flex-1 bg-white text-black rounded-3xl p-8 shadow-2xl overflow-y-auto mb-8">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <h3 className="text-2xl font-bold leading-tight">UNLEGEND<br/>STUDIO</h3>
                  <div className="text-[8px] text-neutral-500 mt-2 uppercase tracking-widest leading-relaxed">
                    {STUDIO_DETAILS.address}<br/>
                    {STUDIO_DETAILS.subAddress}<br/>
                    {STUDIO_DETAILS.city}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-neutral-400">Invoice</p>
                  <p className="text-sm font-bold">{selectedInvoice.invoiceNumber}</p>
                </div>
              </div>

              <div className="mb-12">
                <p className="text-[8px] font-bold uppercase tracking-widest text-neutral-400 mb-1">Bill To</p>
                <p className="text-lg font-bold">{selectedInvoice.clientName}</p>
                <p className="text-[10px] text-neutral-500">{selectedInvoice.clientPhone}</p>
              </div>

              <div className="space-y-4 mb-12">
                <div className="flex justify-between border-b border-neutral-100 pb-2 text-[8px] font-bold uppercase tracking-widest text-neutral-400">
                  <span>Description</span>
                  <span>Total</span>
                </div>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-sm font-bold">Recording Session</p>
                    <p className="text-[10px] text-neutral-500">{selectedInvoice.durationHours}h {selectedInvoice.durationMinutes}m @ ₹{selectedInvoice.hourlyRate}/hr</p>
                  </div>
                  <p className="text-lg font-bold">₹{selectedInvoice.totalAmount}</p>
                </div>
              </div>

              <div className="mt-auto pt-12 border-t border-neutral-100 flex justify-between items-center">
                <div>
                  <p className="text-[8px] font-bold uppercase tracking-widest text-neutral-400">Date</p>
                  <p className="text-xs font-bold">{format(selectedInvoice.date, 'dd MMM yyyy')}</p>
                </div>
                <div className="text-right">
                  <p className="text-[8px] font-bold uppercase tracking-widest text-neutral-400">Total Amount</p>
                  <p className="text-2xl font-bold">₹{selectedInvoice.totalAmount}</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <LuxuryButton onClick={() => generatePDF(selectedInvoice)} variant="secondary" className="py-5">
                <Download className="w-5 h-5" />
                PDF
              </LuxuryButton>
              <LuxuryButton onClick={() => shareWhatsApp(selectedInvoice)} className="py-5">
                <Share2 className="w-5 h-5" />
                WhatsApp
              </LuxuryButton>
            </div>
          </motion.div>
        )}

        {view === 'history' && (
          <motion.div
            key="history"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="flex-1 p-8 flex flex-col"
          >
            <header className="flex items-center gap-4 mb-10">
              <button onClick={() => setView('home')} className="p-2 -ml-2 hover:bg-luxury-charcoal rounded-full transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h2 className="text-2xl font-bold">History</h2>
            </header>

            <div className="space-y-4 overflow-y-auto pb-8 no-scrollbar">
              {invoices.length > 0 ? (
                invoices.map((inv) => (
                  <motion.div
                    key={inv.id}
                    whileHover={{ scale: 1.02 }}
                    onClick={() => { setSelectedInvoice(inv); setView('preview'); }}
                    className="bg-luxury-charcoal/50 p-6 rounded-3xl border border-luxury-charcoal hover:border-luxury-silver/20 transition-all cursor-pointer flex justify-between items-center"
                  >
                    <div className="space-y-1">
                      <p className="font-bold">{inv.clientName}</p>
                      <div className="flex items-center gap-3 text-[10px] text-luxury-silver uppercase tracking-widest">
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {format(inv.date, 'dd MMM yyyy')}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {inv.durationHours}h {inv.durationMinutes}m</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-display font-bold">₹{inv.totalAmount}</p>
                      <p className="text-[8px] text-luxury-silver uppercase tracking-widest">{inv.invoiceNumber}</p>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center py-20 text-luxury-silver">
                  <History className="w-12 h-12 mb-4 opacity-20" />
                  <p>No history found</p>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {view === 'clients' && (
          <motion.div
            key="clients"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="flex-1 p-8 flex flex-col"
          >
            <header className="flex items-center gap-4 mb-10">
              <button onClick={() => setView('home')} className="p-2 -ml-2 hover:bg-luxury-charcoal rounded-full transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h2 className="text-2xl font-bold">Clients</h2>
            </header>

            <div className="relative mb-8">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-luxury-silver" />
              <input 
                type="text" 
                placeholder="Search clients..." 
                className="w-full bg-luxury-charcoal rounded-2xl py-4 pl-12 pr-4 outline-none border border-transparent focus:border-luxury-silver/20 transition-all"
              />
            </div>

            <div className="space-y-4 overflow-y-auto pb-8 no-scrollbar">
              {clients.length > 0 ? (
                clients.map((client) => (
                  <div key={client.id} className="bg-luxury-charcoal/50 p-6 rounded-3xl border border-luxury-charcoal flex justify-between items-center">
                    <div className="space-y-1">
                      <p className="font-bold text-lg">{client.name}</p>
                      <p className="text-xs text-luxury-silver">{client.phone}</p>
                    </div>
                    <LuxuryButton 
                      variant="ghost" 
                      className="p-3 rounded-full"
                      onClick={() => {
                        setClientName(client.name);
                        setClientPhone(client.phone);
                        setView('create');
                      }}
                    >
                      <Plus className="w-5 h-5" />
                    </LuxuryButton>
                  </div>
                ))
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center py-20 text-luxury-silver">
                  <Users className="w-12 h-12 mb-4 opacity-20" />
                  <p>No clients found</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
