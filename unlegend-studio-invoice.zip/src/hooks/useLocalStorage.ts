import { useState, useEffect } from 'react';
import { Client, Invoice } from '../types';

const STORAGE_KEYS = {
  CLIENTS: 'unlegend_clients',
  INVOICES: 'unlegend_invoices',
};

export function useLocalStorage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);

  useEffect(() => {
    const storedClients = localStorage.getItem(STORAGE_KEYS.CLIENTS);
    const storedInvoices = localStorage.getItem(STORAGE_KEYS.INVOICES);

    if (storedClients) setClients(JSON.parse(storedClients));
    if (storedInvoices) setInvoices(JSON.parse(storedInvoices));
  }, []);

  const saveClients = (newClients: Client[]) => {
    setClients(newClients);
    localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(newClients));
  };

  const saveInvoices = (newInvoices: Invoice[]) => {
    setInvoices(newInvoices);
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(newInvoices));
  };

  const addClient = (client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...client,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
    };
    saveClients([newClient, ...clients]);
    return newClient;
  };

  const addInvoice = (invoice: Omit<Invoice, 'id' | 'createdAt' | 'invoiceNumber'>) => {
    const newInvoice: Invoice = {
      ...invoice,
      id: crypto.randomUUID(),
      invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
      createdAt: Date.now(),
    };
    saveInvoices([newInvoice, ...invoices]);
    return newInvoice;
  };

  return {
    clients,
    invoices,
    addClient,
    addInvoice,
  };
}
