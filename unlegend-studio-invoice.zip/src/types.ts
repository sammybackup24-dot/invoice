export interface Client {
  id: string;
  name: string;
  phone: string;
  createdAt: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  date: number;
  durationHours: number;
  durationMinutes: number;
  hourlyRate: number;
  totalAmount: number;
  createdAt: number;
}

export interface StudioDetails {
  name: string;
  address: string;
  subAddress: string;
  city: string;
  contact: string;
}

export const STUDIO_DETAILS: StudioDetails = {
  name: "Unlegend Studio",
  address: "3rd Floor, A&A Offices",
  subAddress: "Ratan Lok Colony, Near Medanta",
  city: "Indore, Madhya Pradesh, India",
  contact: "9098692404"
};
